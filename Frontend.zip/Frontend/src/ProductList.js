// src/components/ProductList.js
import React, { useState, useEffect } from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  TextField,
  ListItemIcon,
  Checkbox,
} from "@mui/material";
import { Add, Delete, Edit } from "@mui/icons-material";

const initialProducts = [
  // Add more dummy products here
];

const ProductList = () => {
  const [products, setProducts] = useState(initialProducts);
  const [open, setOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [selectedItems, setSelectedItems] = useState([]); // used for selected items for generating bill

  useEffect(() => {
    fetch('http://127.0.0.1:8003/allitems/')
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch products.');
        }
        return response.json();
      })
      .then(data => {
        setProducts(data);
      })
      .catch(error => {
        console.error('Error fetching products:', error);
      });
  }, []); 

  const handleClickOpen = (product, toggleSelect) => {
    if (toggleSelect) {
      setSelectedItems((prevSelectedItems) =>
        prevSelectedItems.some((item) => item.id === product.id)
          ? prevSelectedItems.filter((item) => item.id !== product.id)
          : [...prevSelectedItems, product]
      );
    } else {
      setSelectedProduct(product);
      setName(product ? product.name : "");
      setPrice(product ? product.price : "");
      setDescription(product ? product.description : "");
      setOpen(true);
    }
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSave = () => {
    if (!name.trim() || !price.trim() || !description.trim()) {
      alert("Name, price, and description are all required.");
      return;
    }
    //text validations are left
    if (parseFloat(price) < 0) {
      alert("Price cannot be negative.");
      return;
    }

    let updatedProducts = [];
    if (selectedProduct?.id) {
      updatedProducts = products.map((p) => {
        return p.id === selectedProduct.id
          ? { ...p, name, price, description }
          : p;
      });
    }

    setProducts(
      selectedProduct
        ? updatedProducts
        : [...products, { id: Date.now(), name, price, description }]
    );

    const productData = {
      name: name.trim(),
      price: parseFloat(price.trim()),
      description: description.trim()
    };
  
    fetch('http://127.0.0.1:8003/items/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(productData)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to save product.');
      }
      return response.json();
    })
    .then(data => {
      // Handle successful response, e.g., update local state or show a success message
      console.log('Product saved successfully:', data);
    })
    .catch(error => {
      // Handle error, e.g., show an error message
      console.error('Error saving product:', error);
    });

    setOpen(false);
  };

  const handleDelete = (id) => {
    setProducts(products.filter((p) => p.id !== id));
    setSelectedItems(selectedItems.filter((p) => p.id !== id));
  };

  const handleGenerateBill = () => {
    // known issue when price is changed for already selected item that does not
    // get relflected in total bill
    const totalPrice = selectedItems.reduce(
      (total, item) => total + parseFloat(item.price.replace("$", "")),
      0
    );
    const billItems = selectedItems
      .map((item) => `${item.name} - ${item.price}`)
      .join("\n");
    alert(`Total Price: $${totalPrice.toFixed(2)}\n\nItems:\n${billItems}`);
  };

  return (
    <>
      <List>
        {products.map((product) => (
          <ListItem
            key={product.id}
            button
            onClick={() => handleClickOpen(product, true)}
          >
            <ListItemIcon>
              <Checkbox
                checked={selectedItems.some((item) => item.id === product.id)}
              />
            </ListItemIcon>
            <ListItemText
              primary={
                <div>
                  {product.name}
                  <br />
                  {product.price}
                </div>
              }
              secondary={product.description}
            />
            <ListItemSecondaryAction>
              <IconButton onClick={() => handleClickOpen(product)}>
                <Edit />
              </IconButton>
              <IconButton onClick={() => handleDelete(product.id)}>
                <Delete />
              </IconButton>
            </ListItemSecondaryAction>
          </ListItem>
        ))}
      </List>
      <div style={{ display: "flex" }}>
        <Button
          style={{ margin: "0 8px" }}
          variant="contained"
          onClick={() => handleClickOpen(null)}
          startIcon={<Add />}
        >
          Add Product
        </Button>
        <Button
          style={{ margin: "0 8px" }}
          variant="contained"
          onClick={handleGenerateBill}
          disabled={selectedItems.length === 0}
        >
          Generate Bill
        </Button>
      </div>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>
          {selectedProduct ? "Edit Product" : "Add Product"}
        </DialogTitle>
        <DialogContent>
          <TextField
            label="Name"
            fullWidth
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            label="Price"
            fullWidth
            value={price}
            onChange={(e) => setPrice(e.target.value)}
          />
          <TextField
            label="Description"
            fullWidth
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
export default ProductList;
