import "./styles.css";
import { Container, Typography } from "@mui/material";
import ProductList from "./ProductList";

export default function App() {
  return (
    <Container>
      <Typography variant="h4" component="h1" align="center" gutterBottom>
        Item Manager
      </Typography>
      <ProductList />
    </Container>
  );
}
