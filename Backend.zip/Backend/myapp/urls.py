from rest_framework.routers import DefaultRouter
from django.urls import path
from .views import create_item, all_items
router = DefaultRouter()


urlpatterns = [
  path('items/', create_item),
  path('allitems/', all_items, name='all_items'),
]



urlpatterns = router.urls
