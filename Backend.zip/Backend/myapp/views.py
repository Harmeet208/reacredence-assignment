from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Item
from rest_framework import viewsets
from .models import Item
from .serializers import ItemSerializer

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer

class AllItemsViewSet(viewsets.ViewSet):
    def list(self, request):
        queryset = Item.objects.all()
        serializer = ItemSerializer(queryset, many=True)
        return Response(serializer.data)

@api_view(['POST'])
def create_item(request):
    data = request.data
    item = Item.objects.create(
        name=data['name'],
        description=data['description'],
        price=data['price']
    )
    return Response({"message": "Item created successfully", "id": item.id})

@api_view(['GET'])
def all_items():
    items = Item.objects.all()
    data = [{'id': item.id, 'name': item.name, 'description': item.description, 'price': item.price} for item in items]
    return Response(data)
